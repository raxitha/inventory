<script>
    window.location.href='dashboard'
</script>