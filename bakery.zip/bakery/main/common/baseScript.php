<script>
    var baseSet = "<?php echo ($_SERVER['HTTP_HOST'] === 'nayanfood.in') ? 'http://nayanfood.in/bakery/main/common' : 'http://localhost/bakery/main/common'; ?>";
</script>
