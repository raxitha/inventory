<script>
    window.location.href='main/dashboard'
</script>